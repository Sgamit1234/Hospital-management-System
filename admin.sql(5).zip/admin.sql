-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 29, 2024 at 04:24 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `adname` varchar(20) NOT NULL,
  `ademail` varchar(20) NOT NULL,
  `adphone` int(20) NOT NULL,
  `adpass` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adname`, `ademail`, `adphone`, `adpass`) VALUES
('Sanjana Gamit', 'sanjugamit2001@gmail', 2147483647, 'Sanjana*123456'),
('Binjal', 'binjal123@gmail.com', 1234567890, 'Binjal1234');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE IF NOT EXISTS `appointment` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `aname` varchar(50) NOT NULL,
  `adob` date NOT NULL,
  `anumber` int(50) NOT NULL,
  `aemail` varchar(50) NOT NULL,
  `asymtoms` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `appointment`
--


-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE IF NOT EXISTS `doctor` (
  `did` int(20) NOT NULL AUTO_INCREMENT,
  `dname` varchar(20) NOT NULL,
  `dphone` int(10) NOT NULL,
  `demail` varchar(50) NOT NULL,
  `dspec` varchar(50) NOT NULL,
  `hname` varchar(50) NOT NULL,
  `dpass` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`did`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`did`, `dname`, `dphone`, `demail`, `dspec`, `hname`, `dpass`, `status`) VALUES
(20, 'Rina Nimbal', 2147483647, 'rina1234@gmail.com', 'AAAA', 'SS', '123456', 'approved'),
(16, 'Gamit Sanjana ', 2147483647, 'sanjugamit2001@gmail.com', 'Cardiologist', 'Sunflower', 'Sanju@2001', 'approved'),
(18, 'Sanjana', 1234567890, 'rina123@gmail.com', 'Doctor', 'V.S hospital', 'Rina123456', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `fname` varchar(50) NOT NULL,
  `femail` varchar(50) NOT NULL,
  `fage` varchar(20) NOT NULL,
  `ans1` varchar(20) NOT NULL,
  `ans2` varchar(20) NOT NULL,
  `ans3` varchar(20) NOT NULL,
  `ans4` varchar(20) NOT NULL,
  `feed` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`fname`, `femail`, `fage`, `ans1`, `ans2`, `ans3`, `ans4`, `feed`) VALUES
('sanjana', 'sanjugamit200@hmail.com', '10', 'Adequate', 'Adequate', 'Adequate', 'Satisfactory', 'dddss');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE IF NOT EXISTS `patient` (
  `pid` int(20) NOT NULL AUTO_INCREMENT,
  `pname` varchar(20) NOT NULL,
  `pnumber` int(20) NOT NULL,
  `pemail` varchar(50) NOT NULL,
  `pdob` date NOT NULL,
  `page` varchar(50) NOT NULL,
  `ppass` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`pid`, `pname`, `pnumber`, `pemail`, `pdob`, `page`, `ppass`, `status`) VALUES
(26, 'Arti Gamit', 2147483647, 'arti123@gmail.com', '2006-02-04', '18', 'ArtiGamit11234', 'approved'),
(24, 'Rina Nimbal', 1234567890, 'sanju123@gmail.com', '2020-10-01', '4', 'Rina1234', 'approved'),
(22, 'Patel Hiral D', 789546231, 'hiralpatel1234@gmail.com', '2005-05-07', '17', 'Hiral @34567', 'approved'),
(23, 'CHaudhari Minal S', 2147483647, 'minalchaudhari234@gmail.com', '2001-08-19', '22', 'minal@890644', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `patientappointment`
--

CREATE TABLE IF NOT EXISTS `patientappointment` (
  `pid` int(10) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `pdob` date NOT NULL,
  `pgender` varchar(50) NOT NULL,
  `pbloodgroup` varchar(50) NOT NULL,
  `pnumber` int(30) NOT NULL,
  `paddress` varchar(50) NOT NULL,
  `preason` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patientappointment`
--

INSERT INTO `patientappointment` (`pid`, `pname`, `pdob`, `pgender`, `pbloodgroup`, `pnumber`, `paddress`, `preason`) VALUES
(24, 'Rina Nimbal', '2020-10-01', 'F', 'B+', 1234567890, 'gvghxghsx', 'jjxjxjjxmxx'),
(24, 'Rina Nimbal', '2020-10-01', 'Female', 'B+', 1234567890, 'Amdavad', 'Fever'),
(23, 'CHaudhari Minal S', '2001-08-19', 'F', 'B+', 2147483647, 'minalchaudhari234@gmail.com', 'Feveer');

-- --------------------------------------------------------

--
-- Table structure for table `treatment`
--

CREATE TABLE IF NOT EXISTS `treatment` (
  `treatmentid` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL,
  `treatmentdetails` varchar(80) NOT NULL,
  PRIMARY KEY (`treatmentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `treatment`
--

INSERT INTO `treatment` (`treatmentid`, `pid`, `treatmentdetails`) VALUES
(17, 24, 'paracetamol'),
(18, 24, 'ssss'),
(19, 22, 'qwqqe'),
(20, 22, 'cdvfvf'),
(21, 22, 'ggggh'),
(22, 23, 'vvvvvvv\r\n\r\n\r\n');
