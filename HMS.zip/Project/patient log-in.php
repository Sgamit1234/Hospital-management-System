<?php 

mysql_connect("localhost","root","");
mysql_select_db('admin');

	session_start();
	if(ISSET($_POST['login'])){
		$username = $_POST['pname'];
		$password = $_POST['ppass'];
		
		$query = mysql_query("SELECT * FROM patient WHERE status='approved' AND `pname` = '$username' AND `ppass` = '$password'");
		$fetch = mysql_fetch_array($query);
		$row = mysql_num_rows($query);
		
		if($row > 0){
			$_SESSION['id']=$fetch['pid'];
			echo "<script>alert('Login Successfully!')</script>";
			echo "<script>window.location='patient-profile.php'</script>";
		}else{
			echo "<script>alert('Invalid username or password/not approved')</script>";
			echo "<script>window.location='Patient Login.php'</script>";
		}
		
	}
?>