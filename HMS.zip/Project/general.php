<?php 

mysql_connect("localhost","root","");
mysql_select_db('admin');

	session_start();
	if(ISSET($_POST['login'])){
		$username = $_POST['pname'];
		$password = $_POST['pdob'];
		$query = mysql_query("SELECT * FROM appointment WHERE status='approved' AND `aname` = '$username' AND `adob` = '$password'");
		$fetch = mysql_fetch_array($query);
		$row = mysql_num_rows($query);
		
		if($row > 0){
			$_SESSION['id']=$fetch['aid'];
			echo "<script>alert('Login Successfully!')</script>";
			echo "<script>window.location='view report.php'</script>";
		}else{
			echo "<script>alert('Invalid username or password/not approved')</script>";
			echo "<script>window.location='general report.php'</script>";
		}
		
	}
?>