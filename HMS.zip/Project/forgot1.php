<?php 
$con=mysql_connect("localhost","root","");
if(!$con)
{
	echo"connection Error".mysql_error();
}
$d=mysql_select_db('admin');
if(!$d)
{
	echo"Database not available".mysql_error();
}
	$username = $_POST['pname'];
        $password = $_POST['pdob'];
        $newpassword = $_POST['pnpass'];
        $result = mysql_query("SELECT password FROM patient WHERE pname ='$username'AND pdob ='$password' ");
        if(!$result)
        {
        echo "The username you entered does not exist";
        }
        else if($password!= mysql_result($result, 0))
        {
        echo "You entered an correct password";
        }
        if($password=$_POST['pdob'])
        $sql=mysql_query("UPDATE patient SET ppass='$newpassword' where pname='$username'");
        if($sql)
        {
                echo "<script>alert('Password Updated')</script>";
                echo "<script>window.location='Patient Login.php'</script>";
        }
       else
        {
                echo "<script>alert('Invalid password')</script>";
                echo "<script>window.location='forgotpassword.php'</script>";
       }
      ?>