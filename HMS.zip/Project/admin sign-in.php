<?php
$con=mysql_connect("localhost","root","");
if(!$con)
{
	echo"connection Error".mysql_error();	
}
$d=mysql_select_db('admin');
if(!$d)
{
	echo"<br>Database not avilable".mysql_error();
}
	$f=$_REQUEST['adname'];
	$mi=$_REQUEST['adphone'];
	$e=$_REQUEST['ademail'];
	$y=$_REQUEST['adpass'];
	
	
$q="INSERT INTO admin(adname,adphone,ademail,adpass)VALUES('$f','$mi','$e','$y')";
$r=mysql_query($q,$con);
if($r)
{
	echo "<script>alert('Registered Successfully!')</script>";
	echo "<script>window.location='admin log-in.php'</script>";
}
else
{
	echo"Error".mysql_error();
}
mysql_close($con);
?>