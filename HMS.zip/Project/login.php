<html>
    <head>
        <title> Little heart</title>
        <!--css-->
        <link rel="stylesheet" href="login.css">
        <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
        <script src="https://cdode.jquery.com/jquery-3.3.1.slim.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
    <body>
      <form method="post" action="patient log-in.php">
    <section id="nav-bar">
        <nav class="navbar navbar-expand-lg navbar-light">
          <i class="fa fa-ambulance"></i>
            <a class="navbar-brand" href="#banner">Little Heart</a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
              <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                  <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                </li>

                  <li class="nav-item">
                    <a class="nav-link" href="sigin.php">Sign-in</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#footer">Contact Us</a>
                  </li>
              </ul>
            </div>
          </nav>
    </section>
    <!--log-in section-->
    <section id="sign-in">
        <div class="container">
        <div class="row">
           <div class="col-md-6" >
            <h3><i class="fa fa-sign-in"></i>Doctor Log-in</h3>
              <img src="dc1.jpg" class="fluid">
              <div class="col">
              <a href="doctor login.php" class="btn">Login</a>
              </div>
            </div>
            <div class="col-md-6">
              <h3><i class="fa fa-sign-in"></i>Patient Log-in</h3>
              <img src="p1.jpg" class="fluid" style="padding-left:6rem; width:25rem;">
              <div class="col">
                <a href="Patient Login.php" class="btn">Login</a>
                </div>
            </div>
           </div>
           </div>
          
     </section>
      <!--footer-->
    <section id="footer">
      <img src="images/wave2.png" class="bottom">
      <div class="container">
        <div class="row">
          <div class="col-md-4 footer-box">
            <p><i class="fa fa-ambulance"></i><b>LITTLE HEART</b></p> 
            <p>Subscribe us to get more consultancy by doctors and to keep your health at it best.</p>
          </div>
          <div class="col-md-4 footer-box">
            <p><b>CONTACT US</b></p> 
            <p><i class="fa fa-map-marker"></i> Health Center ,Surat</p>
            <p><i class="fa fa-phone"></i>+91 7643222222</p>
            <p><i class="fa fa-envelope-o"></i>Littleheart56@gmail.com</p>
          </div>

        </div>
          <hr>
          <p class="copyright"><i class="fa fa-copyright"></i>Website Certified by Little Heart</p>
      </div>
    </section>
  <!------smooth scroll-->  
    <script src="smooth-scroll.min.js"></script> 
    <script>
      var scroll = new SmoothScroll('a[href*="#"]');
    </script>
    </form>
</body>
</html>