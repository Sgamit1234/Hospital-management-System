<?php
$con=mysql_connect("localhost","root","");
if(!$con)
{
	echo"connection Error".mysql_error();	
}
$d=mysql_select_db('admin');
if(!$d)
{
	echo"<br>Database not avilable".mysql_error();
}
	$f=$_REQUEST['dname'];
	$mi=$_REQUEST['dnumber'];
	$e=$_REQUEST['demail'];
	$y=$_REQUEST['dspec'];
	$p=$_REQUEST['hname'];	
	$b=$_REQUEST['dpass'];

	
$q="INSERT INTO doctor(dname,dphone,demail,dspec,hname,dpass,status)VALUES('$f','$mi','$e','$y','$p','$b','pending')";
$r=mysql_query($q,$con);
if($r)
{
	echo "<script>alert('Registration Successfully!')</script>";
	echo "<script>window.location='doctor login.php'</script>";
}
else
{
	echo"Error".mysql_error();
}
mysql_close($con);
?>