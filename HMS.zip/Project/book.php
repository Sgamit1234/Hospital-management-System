<?php
$con=mysql_connect("localhost","root","");
if(!$con)
{
	echo"connection Error".mysql_error();	
}
$d=mysql_select_db('admin');
if(!$d)
{
	echo"<br>Database not avilable".mysql_error();
}
	$f=$_REQUEST['pid'];
	$mi=$_REQUEST['paname'];
	$e=$_REQUEST['pagender'];
	$y=$_REQUEST['padob'];
	$p=$_REQUEST['pabg'];	
	$b=$_REQUEST['panumber'];
 	   $k=$_REQUEST['paadd'];
   $h=$_REQUEST['appreason'];

	
$q="INSERT INTO patientappointment(pid,pname,pgender,pdob,pbloodgroup,pnumber ,paddress,preason)VALUES('$f','$mi','$e','$y','$p','$b','$k','$h')";
$r=mysql_query($q,$con);
if($r)
{
    echo "<script>alert('Appointment record inserted successfully...');</script>";
    echo "<script>window.location='bookappointment.php'</script>";
}
else
{
	echo"Error".mysql_error();
}
mysql_close($con);
?>