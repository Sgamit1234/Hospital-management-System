<?php 

mysql_connect("localhost","root","");
mysql_select_db('admin');

	session_start();
	if(ISSET($_POST['login'])){
		$username = $_POST['dname'];
		$password = $_POST['dpass'];
	
		$query = mysql_query("SELECT * FROM `doctor` WHERE status='approved' AND `dname` = '$username' AND `dpass` = '$password' ") or die(mysql_error());
		$fetch = mysql_fetch_array($query);
		$row = mysql_num_rows($query);
		
		if($row > 0){
			$_SESSION['id']=$fetch['did'];
			echo "<script>alert('Login Successfully!')</script>";
			echo "<script>window.location='doctor-panel.php'</script>";
		}else{
			echo "<script>alert('Invalid username or password')</script>";
			echo "<script>window.location='doctor login.php'</script>";
		}
		
	}
?>