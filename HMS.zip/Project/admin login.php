<?php 

mysql_connect("localhost","root","");
mysql_select_db('admin');

	session_start();
	if(ISSET($_POST['login'])){
		$username = $_POST['adname'];
		$password = $_POST['adpass'];
	
		$query = mysql_query("SELECT * FROM `admin` WHERE `adname` = '$username' AND `adpass` = '$password' ") or die(mysql_error());
		$fetch = mysql_fetch_array($query);
		$row = mysql_num_rows($query);
		
		if($row > 0){
			$_SESSION['id']=$fetch['adname'];
			echo "<script>alert('Login Successfully!')</script>";
			echo "<script>window.location='ad.php'</script>";
		}else{
			echo "<script>alert('Invalid username or password')</script>";
			echo "<script>window.location='admin log-in.php'</script>";
		}
		
	}
?>