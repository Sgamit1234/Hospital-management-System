<?php
$con=mysql_connect("localhost","root","");
if(!$con)
{
	echo"connection Error".mysql_error();	
}
$d=mysql_select_db('admin');
if(!$d)
{
	echo"<br>Database not avilable".mysql_error();
}
	$f=$_REQUEST['pname'];
	$mi=$_REQUEST['pnumber'];
	$e=$_REQUEST['pemail'];
	$y=$_REQUEST['pdob'];
	$p=$_REQUEST['page'];	
	$b=$_REQUEST['ppass'];

	
$q="INSERT INTO patient(pname,pnumber,pemail,pdob,page,ppass,status)VALUES('$f','$mi','$e','$y','$p','$b','pending')";
$r=mysql_query($q,$con);
if($r)
{
	echo "<script>alert('Registration Successfully!')</script>";
	echo "<script>window.location='patient Login.php'</script>";
}
else
{
	echo"Error".mysql_error();
}
mysql_close($con);
?>