<?php
$con=mysql_connect("localhost","root","");
if(!$con)
{
	echo"connection Error".mysql_error();	
}
$d=mysql_select_db('admin');
if(!$d)
{
	echo"<br>Database not avilable".mysql_error();
}
	$f=$_REQUEST['pid'];
	$mi=$_REQUEST['treatment'];

	
$q="INSERT INTO treatment(pid,treatmentdetails)VALUES('$f','$mi')";
$r=mysql_query($q,$con);
if($r)
{
    echo "<script>alert('Treatment record inserted successfully...');</script>";
    echo "<script>window.location='doctor-panelpatientapproved.php'</script>";
}
else
{
	echo"Error".mysql_error();
}
mysql_close($con);
?>