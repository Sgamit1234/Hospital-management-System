<?php
$con=mysql_connect("localhost","root","");
if(!$con)
{
	echo"connection Error".mysql_error();	
}
$d=mysql_select_db('admin');
if(!$d)
{
	echo"<br>Database not avilable".mysql_error();
}
	$f=$_REQUEST['fname'];
	$e=$_REQUEST['femail'];
	$a=$_REQUEST['fage'];
	$an=$_REQUEST['ans1'];
	$b=$_REQUEST['ans2'];
	$c=$_REQUEST['ans3'];
	$d=$_REQUEST['ans4'];
	$feed=$_REQUEST['fd'];	
	

	
$q="INSERT INTO feedback(fname,femail,fage,ans1,ans2,ans3,ans4,fd)VALUES('$f','$e','$a','$an','$b','$c','$d','$feed')";
$r=mysql_query($q,$con);
if($r)
{
	echo"<h1>Feedback Submitted</h1>";
}
else
{
	echo"Error".mysql_error();
}
mysql_close($con);
?>