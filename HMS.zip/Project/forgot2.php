<?php 
$con=mysql_connect("localhost","root","");
if(!$con)
{
	echo"connection Error".mysql_error();
}
$d=mysql_select_db('admin');
if(!$d)
{
	echo"Database not available".mysql_error();
}
	$username = $_POST['dname'];
        $password = $_POST['demail'];
        $newpassword = $_POST['pnpass'];
        $result = mysql_query("SELECT password FROM doctor WHERE dname ='$username'AND demail ='$password' ");
        if(!$result)
        {
        echo "The username you entered does not exist";
        }
        else if($password!= mysql_result($result, 0))
        {
        echo "You entered an correct password";
        }
        if($password=$_POST['demail'])
        $sql=mysql_query("UPDATE doctor SET dpass='$newpassword' where dname='$username'");
        if($sql)
        {
                echo "<script>alert('Password Updated')</script>";
                echo "<script>window.location='doctor login.php'</script>";
        }
       else
        {
                echo "<script>alert('Invalid password')</script>";
                echo "<script>window.location='forgotpassword2.php'</script>";
       }
      ?>