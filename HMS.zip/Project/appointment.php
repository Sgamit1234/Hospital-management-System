<?php
$con=mysql_connect("localhost","root","");
if(!$con)
{
	echo"connection Error".mysql_error();	
}
$d=mysql_select_db('admin');
if(!$d)
{
	echo"<br>Database not avilable".mysql_error();
}
	$f=$_REQUEST['aname'];
	$mi=$_REQUEST['adob'];
	$e=$_REQUEST['anumber'];
	$y=$_REQUEST['aemail'];
	$p=$_REQUEST['asymtoms'];	

	
$q="INSERT INTO appointment(aname,adob,anumber,aemail,asymtoms,status)VALUES('$f','$mi','$e','$y','$p','pending')";
$r=mysql_query($q,$con);
if($r)
{

echo "<script>alert('Request sent Successfully!')</script>";
			echo "<script>window.location='home.php'</script>";
}
else
{
	echo"Error".mysql_error();
}
mysql_close($con);
?>